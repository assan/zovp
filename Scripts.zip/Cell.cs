using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Cell : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{

    public Inventory inventory;
    public TMP_Text cellIndex;
    public int x, y;
    public bool isFree;
    public Image image;

    void Start()
    {
        image = GetComponent<Image>();
        // �������� ���������������� inventory ����� Singleton, ���� �� ��� �� ����������
        if (inventory == null)
        {
            inventory = FindObjectOfType<Inventory>();
            if (inventory == null)
            {
                Debug.LogError($"Inventory not found for cell: {gameObject.name}");
            }
        }


    }

    void Update()
    {
    }

    public void OnDrop(PointerEventData eventData)
    {
        var dragItem = eventData.pointerDrag.GetComponent<Item>();
        if (dragItem == null)
        {
            Debug.LogWarning($"No Item component found on dragged object in cell: {gameObject.name}");
            return;
        }

        if (inventory == null)
        {
            Debug.LogError($"Inventory is null in OnDrop for cell: {gameObject.name}");
            return;
        }

        Debug.Log($"Dropping item {dragItem.gameObject.name} on cell ({x}, {y})");
        // ���������� ������ �������������� � Item.OnEndDrag
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (inventory == null)
        {
            Debug.LogError($"Inventory is null in OnPointerEnter for cell: {gameObject.name}");
            return;
        }

        if (inventory.DragedItem)
        {
            bool isFree = inventory.CheckCellFree(this, inventory.DragedItem.GetSize());
            Debug.Log($"Pointer entered cell ({x}, {y}): isFree = {isFree}");
            if (isFree)
            {
                inventory.Coloring(this, inventory.DragedItem.GetSize(), Color.green);
            }
            else
            {
                inventory.Coloring(this, inventory.DragedItem.GetSize(), Color.red);
            }
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (inventory == null)
        {
            Debug.LogError($"Inventory is null in OnPointerExit for cell: {gameObject.name}");
            return;
        }

        if (inventory.DragedItem)
        {
            Debug.Log($"Pointer exited cell ({x}, {y})");
            inventory.Coloring(this, inventory.DragedItem.GetSize(), Color.black);
        }
    }

    public void Initialized(Inventory inv)
    {
        inventory = inv;
        if (inventory == null)
        {
            Debug.LogError($"Inventory passed to Initialized is null for cell: {gameObject.name}");
        }

    }
}